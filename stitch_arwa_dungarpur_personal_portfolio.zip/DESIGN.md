---
name: Technical Sophistication
colors:
  surface: '#fcf8fe'
  surface-dim: '#dcd9df'
  surface-bright: '#fcf8fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f2f8'
  surface-container: '#f0edf3'
  surface-container-high: '#eae7ed'
  surface-container-highest: '#e4e1e7'
  on-surface: '#1b1b1f'
  on-surface-variant: '#494454'
  inverse-surface: '#303034'
  inverse-on-surface: '#f3eff6'
  outline: '#7b7486'
  outline-variant: '#cbc3d7'
  surface-tint: '#6d3bd7'
  primary: '#6b38d4'
  on-primary: '#ffffff'
  primary-container: '#8455ef'
  on-primary-container: '#fffbff'
  inverse-primary: '#d0bcff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#7e5300'
  on-tertiary: '#ffffff'
  tertiary-container: '#9e6a08'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb2'
  tertiary-fixed-dim: '#fbbb5a'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#fcf8fe'
  on-background: '#1b1b1f'
  surface-variant: '#e4e1e7'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  section-gap: 120px
  container-padding: 24px
  gutter: 32px
---

## Brand & Style

This design system is engineered for a high-end personal portfolio that bridges the gap between technical rigor and premium aesthetics. It targets a professional audience within the tech and engineering sectors, evoking a sense of precision, innovation, and elite craftsmanship.

The visual direction is a refined blend of **Modern Minimalism** and **Glassmorphism**. While originally conceived as a dark terminal aesthetic, this light-mode evolution maintains the same structural "Modernist" clarity. It utilizes clean, airy surfaces to create an expansive canvas, allowing vibrant accents and translucent layers to guide the eye. The interface feels like a high-end laboratory—clean, spacious, and highly functional, yet softened by organic shadows and rounded geometries to maintain an approachable, professional warmth.

## Colors

The palette has transitioned to a light-mode foundation to provide a clean, clinical backdrop for technical content. 
- **Primary & Secondary:** A high-energy gradient spanning Electric Purple to Cyan Blue is reserved for calls to action, active states, and progress indicators.
- **Tertiary:** A new Golden-Amber accent (#E5A748) is introduced to highlight featured technical projects and special callouts.
- **Neutrals:** The system uses a deep neutral foundation (#0B0B0F) for typography and iconography to ensure maximum legibility against the light background surfaces.
- **Semantic Colors:** Success, Warning, and Error states utilize high-luminance tones to fit the light aesthetic while maintaining clear visibility.

## Typography

The system relies on **Manrope** for its balance of geometric clarity and modern friendliness. 
- **Headings:** Use bold or extra-bold weights with tight letter-spacing to create a "SaaS-startup" impact.
- **Body:** Standard weight with generous line-height ensures readability against the bright, clean backgrounds.
- **Technical Accents:** **JetBrains Mono** (monospaced) is used for labels, code snippets, and metadata to reinforce the engineering theme.

## Layout & Spacing

This design system uses a **Fluid Grid** model with a focus on expansive white space to highlight individual projects.
- **Desktop:** A 12-column grid with wide 32px gutters. Margins are generous to prevent content from feeling crowded.
- **Mobile:** Reflows to a single column with 24px side margins. 
- **Rhythm:** All spacing is derived from an 8px base unit. Section vertical spacing should be aggressive (120px+) to allow the portfolio pieces room to breathe, creating a "gallery" feel.

## Elevation & Depth

Depth is achieved through **Glassmorphism** and light-source simulation.
- **Surfaces:** Use backdrop blurs (20px to 40px) on semi-transparent white background fills (approx. 70-80% opacity) to create a frosted glass effect.
- **Outlines:** Every elevated card or container must have a 1px border. Use a subtle light-grey stroke to define boundaries without heavy visual weight.
- **Shadows:** Use large, ultra-soft shadows. Shadows should have a high blur radius (40px-60px) with very low opacity (5-10%) and can be subtly tinted with the primary purple or tertiary amber to make components appear as if they are floating.

## Shapes

The shape language is ultra-soft and modern. 
- **Cards & Containers:** Utilize a 24px (1.5rem) minimum radius. For larger hero elements, increase to 32px or 48px.
- **Interactive Elements:** Buttons and tags should be fully pill-shaped (rounded-full) to provide a friendly, tactile contrast against the structured grid.
- **Consistency:** Avoid sharp corners entirely; even nested elements (like images inside cards) must follow the 8px-decrement rule to maintain concentricity.

## Components

- **Buttons:** Primary buttons use the Electric-to-Cyan gradient with white text. Secondary buttons are "Ghost" style with the glassmorphic blur and a subtle neutral stroke.
- **Project Cards:** The signature component. High backdrop-blur, subtle inner glow, and 24px corner radius. In light mode, these appear as clean, frosted glass panes.
- **Chips/Tags:** Small, pill-shaped elements. Use JetBrains Mono for the font. Featured tags may utilize the new Tertiary Amber fill.
- **Input Fields:** Recessed white backgrounds with a 1px border that glows Cyan Blue on focus.
- **Progress Bars:** Thin 4px lines with the gradient fill, used for showing technical skill proficiency or project completion status.